public class Demo {
    public static void main(String[] args){
        Book book1=new Book("Silent Patient","Kendal Jenner");
        System.out.println("====BOOK====");
        System.out.println("(Methods called)");
        book1.open();
        book1.close();
        System.out.println("(Display called)");
        book1.display();
        System.out.println("(toString called)");
        System.out.println(book1);
        System.out.println("---------------------------------------------------");
        EBook ebook1=new EBook("History","Historians","compressed",2.3);
        System.out.println("====EBOOK====");
        System.out.println("(Methods called)");
        ebook1.open();
        ebook1.close();
        System.out.println("(Display called)");
        ebook1.display();
        System.out.println("(toString called)");
        System.out.println(ebook1);
        System.out.println("---------------------------------------------------");
        System.out.println("====AUDIO BOOK====");
        AudioBook audbook1=new AudioBook("Physics","John","compressed",3.4,"Fajr",2);
        System.out.println("(Methods called)");
        audbook1.open();
        audbook1.close();
        System.out.println("(Display called)");
        audbook1.display();
        System.out.println("(toString called)");
        System.out.println(audbook1);
    }
}
