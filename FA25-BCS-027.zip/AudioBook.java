public class AudioBook extends EBook{
    protected String narrator;
    protected int duration;
    AudioBook(String title, String author,String fileFormat,double fileSize,String narrator,int duration){
        super(title,author,fileFormat,fileSize);
        this.narrator=narrator;
        this.duration=duration;
    }
    public void display(){
        super.display();
        System.out.println("Narrator: "+narrator);
        System.out.println("Duration: "+duration);
    }
    public String toString(){
        return String.format(super.toString()+", Narrator: %s, Duration: %d",narrator,duration);
    }
}
