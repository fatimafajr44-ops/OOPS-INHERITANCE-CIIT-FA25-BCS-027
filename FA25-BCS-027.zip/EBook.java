public class EBook extends Book{
    protected String fileFormat;
    protected double fileSize;
    EBook(String title, String author,String fileFormat,double fileSize){
        super(title,author);
        this.fileFormat=fileFormat;
        this.fileSize=fileSize;
    }
    public void display(){
        super.display();
        System.out.println("File format: "+fileFormat);
        System.out.println("File size: "+fileSize);
       }
       public String toString(){
    return String.format(super.toString()+", File format: %s, File size: %.2f",fileFormat,fileSize);
    }
}

