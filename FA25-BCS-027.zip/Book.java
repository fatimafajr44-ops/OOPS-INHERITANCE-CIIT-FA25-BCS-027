public class Book {
    protected String title;
    protected String author;
    Book(String title, String author){
        this.title=title;
        this.author=author;
    }
    public void open(){
        System.out.println("Book opened.");
    }
    public void close(){
        System.out.println("Book closed.");
    }
    public void display(){
        System.out.println("Title: "+title);
        System.out.println("Author: "+author);
    }
    public String toString(){
        return String.format("Title: %s, Author: %s",title,author);
    }
}

